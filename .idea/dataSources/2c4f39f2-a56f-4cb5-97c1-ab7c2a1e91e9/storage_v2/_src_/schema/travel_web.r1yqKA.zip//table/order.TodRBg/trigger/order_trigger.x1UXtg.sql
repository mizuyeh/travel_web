create definer = root@localhost trigger order_trigger
    before insert
    on `order`
    for each row
BEGIN
    SET new.id=REPLACE(UUID(),'-',''); -- 触发器执行的逻辑
END;

