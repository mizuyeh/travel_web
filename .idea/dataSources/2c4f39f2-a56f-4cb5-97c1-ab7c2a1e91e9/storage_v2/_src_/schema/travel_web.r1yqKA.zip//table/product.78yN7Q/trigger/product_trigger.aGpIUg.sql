create definer = root@localhost trigger product_trigger
    before insert
    on product
    for each row
BEGIN
    SET new.id=REPLACE(UUID(),'-',''); -- 触发器执行的逻辑
END;

