create definer = root@localhost trigger member_trigger
    before insert
    on member
    for each row
BEGIN
		SET new.id=REPLACE(UUID(),'-',''); -- 触发器执行的逻辑
    END;

