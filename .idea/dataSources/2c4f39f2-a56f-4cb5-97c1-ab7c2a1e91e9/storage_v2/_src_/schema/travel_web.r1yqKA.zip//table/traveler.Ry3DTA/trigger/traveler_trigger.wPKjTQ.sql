create definer = root@localhost trigger traveler_trigger
    before insert
    on traveler
    for each row
BEGIN
    SET new.id=REPLACE(UUID(),'-',''); -- 触发器执行的逻辑
END;

